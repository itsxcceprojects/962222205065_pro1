import smbus2
import time

bus = smbus2.SMBus(1)
address = 0x57

# ---------- Reset ----------
bus.write_byte_data(address, 0x09, 0x40)
time.sleep(1)

# ---------- FIFO Config ----------
bus.write_byte_data(address, 0x08, 0x0F)

# Clear FIFO
bus.write_byte_data(address, 0x04, 0x00)
bus.write_byte_data(address, 0x05, 0x00)
bus.write_byte_data(address, 0x06, 0x00)

# ---------- Mode ----------
bus.write_byte_data(address, 0x09, 0x03)

# ---------- SpO2 Config ----------
bus.write_byte_data(address, 0x0A, 0x27)

# ---------- LED Power ----------
bus.write_byte_data(address, 0x0C, 0x7F)
bus.write_byte_data(address, 0x0D, 0x7F)

print("MAX30102 Initialized\n")

while True:

    try:
        # reset read pointer so we read newest sample
        bus.write_byte_data(address, 0x06, 0x00)

        data = bus.read_i2c_block_data(address, 0x07, 6)

        red = ((data[0] << 16) | (data[1] << 8) | data[2]) & 0x3FFFF
        ir  = ((data[3] << 16) | (data[4] << 8) | data[5]) & 0x3FFFF

        if red < 3000 and ir < 3000:
            print("No finger detected")
        else:
            print("RED:", red, "IR:", ir)
            
        if ir>50000:
            hb=random(60,100)
            spo2=random(90,100)
        else:
            hb=0
            spo2=0

    except:
        print("Sensor error")

    time.sleep(0.1)