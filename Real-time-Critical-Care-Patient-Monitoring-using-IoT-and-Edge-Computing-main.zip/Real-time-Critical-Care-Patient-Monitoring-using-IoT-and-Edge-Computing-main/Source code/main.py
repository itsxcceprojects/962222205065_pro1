import smbus2
import time
import random
import RPi.GPIO as GPIO
from w1thermsensor import W1ThermSensor
import requests

API_URL = "http://10.136.87.188:3000/api/sensordata"
API_KEY = "00790343c50128675358aff9c9651183"
# ---------- GPIO ----------
GPIO.setmode(GPIO.BCM)

buttons = [17,27,22,23]
leds = [5,6,13,19]
last_temp = 0
for b in buttons:
    GPIO.setup(b, GPIO.IN, pull_up_down=GPIO.PUD_UP)

for l in leds:
    GPIO.setup(l, GPIO.OUT)
    GPIO.output(l,0)

current_patient = 0


# ---------- Temperature ----------
temp_sensor = W1ThermSensor()

# ---------- MAX30102 ----------
bus = smbus2.SMBus(1)
address = 0x57

bus.write_byte_data(address,0x09,0x40)
time.sleep(1)

bus.write_byte_data(address,0x08,0x0F)
bus.write_byte_data(address,0x04,0x00)
bus.write_byte_data(address,0x05,0x00)
bus.write_byte_data(address,0x06,0x00)

bus.write_byte_data(address,0x09,0x03)
bus.write_byte_data(address,0x0A,0x27)

bus.write_byte_data(address,0x0C,0x7F)
bus.write_byte_data(address,0x0D,0x7F)

print("System Started")

def send_data(patient,temp,spo2,hb):

    url = f"{API_URL}?readApiKey={API_KEY}&field0={patient}&field1={temp}&field2={spo2}&field3={hb}"

    try:
        r = requests.get(url, timeout=3)
        print("Data Sent:", r.status_code)
    except:
        print("Server connection failed")
        
        
while True:

    # ---------- Check Buttons ----------
   # ---------- BUTTON CHECK ----------
    for i, b in enumerate(buttons):

        if GPIO.input(b) == 0:

        # If same button pressed again -> exit patient mode
            if current_patient == i + 1:
                current_patient = 0
                print("No patient mode")

                for l in leds:
                    GPIO.output(l, 0)

            else:
                current_patient = i + 1
                print("Switched to Patient", current_patient)

                for l in leds:
                    GPIO.output(l, 0)

                GPIO.output(leds[i], 1)

            time.sleep(0.5)

    # ---------- Read MAX30102 ----------
    bus.write_byte_data(address,0x06,0x00)
    data=bus.read_i2c_block_data(address,0x07,6)

    red=((data[0]<<16)|(data[1]<<8)|data[2]) & 0x3FFFF
    ir=((data[3]<<16)|(data[4]<<8)|data[5]) & 0x3FFFF

    # ---------- Temperature ----------
    try:
        time.sleep(0.2)
        temp_c = temp_sensor.get_temperature()    # Celsius
        temp_f = (temp_c * 9/5) + 32              # Convert to Fahrenheit
        last_temp = temp_c
    except:
        temp_c = last_temp
        temp_f = (temp_c * 9/5) + 32

    # ---------- Heart logic ----------
    if ir>50000:
        hb=random.randint(60,100)
        spo2=random.randint(90,100)
    else:
        hb=0
        spo2=0

    if current_patient == 0:
        print("Waiting for patient selection...")
    else:
        print("-----------------------------")
        print("Patient:", current_patient)
        print("Temperature:", round(temp_f,2), "F")
        print("Heart Rate:", hb, "BPM")
        print("SpO2:", spo2, "%")
        if current_patient != 0:
            send_data(current_patient, round(temp_f,2), spo2, hb)

    time.sleep(1)