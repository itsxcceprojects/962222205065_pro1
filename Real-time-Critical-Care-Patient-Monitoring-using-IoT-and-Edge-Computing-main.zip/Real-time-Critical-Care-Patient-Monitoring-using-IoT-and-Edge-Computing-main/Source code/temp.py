from w1thermsensor import W1ThermSensor
import time

sensor = W1ThermSensor()

while True:
    temperature = sensor.get_temperature()
    print("Temperature:", round(temperature,2),"°C")
    time.sleep(1)